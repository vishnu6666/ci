<!DOCTYPE html>
    <head>
      <!-- meta charec set -->
        <meta charset="utf-8">
    <!-- Always force latest IE rendering engine or request Chrome Frame -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <!-- Page Title -->
        <title><?php echo $this->template->title->default("Default title"); ?></title>    
    <!-- Meta Description -->
        <meta name="description" content="Blue One Page Creative HTML5 Template">
        <meta name="keywords" content="one page, single page, onepage, responsive, parallax, creative, business, html5, css3, css3 animation">
        <meta name="author" content="Muhammad Morshed">
    <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php echo $this->template->meta; ?>  
    <!-- Google Font -->
    
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>

    <!-- CSS
    ================================================== -->
    <!-- Fontawesome Icon font -->
        <link rel="stylesheet" href="<?php echo base_url('assets/css/font-awesome.min.css')?>">
    <!-- Twitter Bootstrap css -->
        <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css')?>">
    <!-- jquery.fancybox  -->
        <link rel="stylesheet" href="<?php echo base_url('assets/css/jquery.fancybox.css')?>">
    <!-- animate -->
        <link rel="stylesheet" href="<?php echo base_url('assets/css/animate.css')?>">
    <!-- Main Stylesheet -->
        <link rel="stylesheet" href="<?php echo base_url('assets/css/main.css')?>">
    <!-- media-queries -->
        <link rel="stylesheet" href="<?php echo base_url('assets/css/media-queries.css')?>">
        <?php echo $this->template->stylesheet; ?>

    <!-- Modernizer Script for old Browsers -->
        <script src="<?php echo base_url('assets/js/modernizr-2.6.2.min.js')?>"></script>

    </head>
  
    <body id="body">
  
    <!-- preloader -->
    <!-- <div id="preloader">
      <img src="<?php echo base_url('assets/img/preloader.gif')?>" alt="Preloader">
    </div> -->
    <!-- end preloader -->

    <?php 
    echo $this->template->widget("navigation");
    ?>
    <?php
    // This is the main content partial
    echo $this->template->content;
    ?> 
     <?php 
    echo $this->template->widget("footer");
    ?>

      
    
    <a href="javascript:void(0);" id="back-top"><i class="fa fa-angle-up fa-3x"></i></a>

    <!-- Essential jQuery Plugins
    ================================================== -->
    <!-- Main jQuery -->
        <script src="<?php echo base_url('assets/js/jquery-1.11.1.min.js')?>"></script>
    <!-- Single Page Nav -->
        <script src="<?php echo base_url('assets/js/jquery.singlePageNav.min.js')?>"></script>
    <!-- Twitter Bootstrap -->
        <script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
    <!-- jquery.fancybox.pack -->
        <script src="<?php echo base_url('assets/js/jquery.fancybox.pack.js')?>"></script>
    <!-- jquery.mixitup.min -->
        <script src="<?php echo base_url('assets/js/jquery.mixitup.min.js')?>"></script>
    <!-- jquery.parallax -->
        <script src="<?php echo base_url('assets/js/jquery.parallax-1.1.3.js')?>"></script>
    <!-- jquery.countTo -->
        <script src="<?php echo base_url('assets/js/jquery-countTo.js')?>"></script>
    <!-- jquery.appear -->
        <script src="<?php echo base_url('assets/js/jquery.appear.js')?>"></script>
    <!-- Contact form validation -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery.form/3.32/jquery.form.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.11.1/jquery.validate.min.js"></script>
    <!-- Google Map -->
        <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
    <!-- jquery easing -->
        <script src="<?php echo base_url('assets/js/jquery.easing.min.js')?>"></script>
    <!-- jquery easing -->
        <script src="<?php echo base_url('assets/js/wow.min.js')?>"></script>
    <script>
      var wow = new WOW ({
        boxClass:     'wow',      // animated element css class (default is wow)
        animateClass: 'animated', // animation css class (default is animated)
        offset:       120,          // distance to the element when triggering the animation (default is 0)
        mobile:       false,       // trigger animations on mobile devices (default is true)
        live:         true        // act on asynchronously loaded content (default is true)
        }
      );
      wow.init();
    </script> 
    <!-- Custom Functions -->
        <script src="<?php echo base_url('assets/js/custom.js')?>js/custom.js"></script>
        <?php echo $this->template->javascript; ?>
    
    <script type="text/javascript">
      $(function(){
        /* ========================================================================= */
        /*  Contact Form
        /* ========================================================================= */
        
        $('#contact-form').validate({
          rules: {
            name: {
              required: true,
              minlength: 2
            },
            email: {
              required: true,
              email: true
            },
            message: {
              required: true
            }
          },
          messages: {
            name: {
              required: "come on, you have a name don't you?",
              minlength: "your name must consist of at least 2 characters"
            },
            email: {
              required: "no email, no message"
            },
            message: {
              required: "um...yea, you have to write something to send this form.",
              minlength: "thats all? really?"
            }
          },
          submitHandler: function(form) {
            $(form).ajaxSubmit({
              type:"POST",
              data: $(form).serialize(),
              url:"process.php",
              success: function() {
                $('#contact-form :input').attr('disabled', 'disabled');
                $('#contact-form').fadeTo( "slow", 0.15, function() {
                  $(this).find(':input').attr('disabled', 'disabled');
                  $(this).find('label').css('cursor','default');
                  $('#success').fadeIn();
                });
              },
              error: function() {
                $('#contact-form').fadeTo( "slow", 0.15, function() {
                  $('#error').fadeIn();
                });
              }
            });
          }
        });
      });
    </script>
    </body>
</html>
