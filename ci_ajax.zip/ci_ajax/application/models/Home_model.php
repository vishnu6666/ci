<?php 
class Home_model extends CI_Model{
	protected $table='tbl';
	function __Construct(){
		parent::__Construct();
	}
	public function insert_data($data){
		/*echo "<prev>";
		print_r($data);
		exit();*/
		$sql=$this->db->insert('tbl',$data);
		if($sql)
		{
			echo"data submited.";
		}
		else
		{
			echo"error.";
		}
	}
	function show_data(){
		$res=$this->db->get('tbl');
		return $res->result();
	}
	public function delete_data($id){
		$this->db->where('id',$id);
		if($this->db->delete('tbl'))
			{
				echo "Record deleted..!";
			}
			else
			{
				echo "Error in delete..!";
			}
	}
	function edit_data($id){
		$this->db->select('*');
		$this->db->from('tbl');
		$this->db->where('id',$id);
		$data=$this->db->get();
		$result = $data->result();
		echo json_encode($result);
	}
	function update_data($id,$data){
		/*echo "<prev>";
		print_r($data);
		exit();*/
		$this->db->where('id',$id);
		$sql=$this->db->update('tbl',$data);
		if($sql)
		{
			echo"data update successfully..";
		}
		else
		{
			echo "error..";
		}
	}
}


?>