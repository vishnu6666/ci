<html>
<head>
	<style type="text/css">
	.error{color:red};</style>
	<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.2.1.min.js"></script>
	<script>
		$(document).ready(function()
		{
			$('#submit').click(function(e)
			{
				e.preventDefault();
				var form = $('form')[0];
				var formData = new FormData(form);
				$.ajax(
				{
					type: "POST",
					url : "<?php echo base_url(); ?>/index.php/Welcome/validate",
					cache :false,
					contentType :false,
					processData:false,
					data:formData,
					success:function(data)
					{
						alert(data);
						$.ajax(
						{	
							type : "POST",
							url:"<?php echo base_url(); ?>/index.php/Welcome/show",
							success:function(data)
							{
								$('#view').html(data);
							}
						});
					}
				});
				return false;
			});
		});
		$(function()
		{
			$('#update').click(function(e)
			{
				e.preventDefault();
				$('#submit').show();
				$('#update').hide();
				var form = $('form')[0];
				var formData= new FormData(form);
				$.ajax(
				{
					type:"POST",
					url:"<?php echo base_url();?>/index.php/Welcome/update",
					data:formData,
					cache :false,
					contentType :false,
					processData:false,
					data:formData,
					success:function(data)
					{
						alert(data);
						$.ajax(
						{
							type : "POST",
							url:"<?php echo base_url(); ?>/index.php/Welcome/show",
							success:function(data)
							{
								$('#view').html(data);
							}
						});
					}
				});
				return false;
			});
		});
	</script>
</head>
<body>
<div id="view"></div>
	<form enctype="multipart/form-data"  method="POST" >
		<table align="center" border="1" > 
		<input type="text" name="uid" id="uid" hidden="">
			<tr>
				<td>Name</td>
				<td><input type="text" name="name" id="name"value=""></td>
			</tr>
			<tr>
				<td>Gender</td>
				<td><input type="radio" name="gender"  value="male" id="male">male
					<input type="radio" name="gender" value="female" id="female">female</td>
			</tr>
			<tr>
				<td>Hobby</td>
				<td><input type="checkbox" name="hobby[]" value="fb" id="fb">fb
					<input type="checkbox" name="hobby[]" value="wb" id="wb">wb
					<input type="checkbox" name="hobby[]" value="bb" id="bb">bb</td>
			</tr>
			<tr>
				<td>Education</td>
				<td>
				<select name="education" id="education">
					<option>Be</option>
					<option>Me</option>
					<option>Mtech</option>
				</select></td>
			</tr>
			<tr>
				<td>Image</td>
				<td><input type="file" name="img" >
				<div id="imgs"></div></td>
			</tr>
			<tr>
				<td>Gallery</td>
				<td><input type="file" name="gallery[]" multiple="">
				<div id="gallery"></div>
				</td>
			</tr>
			<tr>
			<td>
				<input type="submit" name="submit" id="submit" value="insert">
				<input type="submit" name="update" id="update" value="update" hidden="" >
			</tr></td>

		</table>
	</form>
</body>
</html>
