<html>
<head>
	<style type="text/css">
	.error{color:red};</style>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.2.1.min.js"></script>
	<script>
		$(document).ready(function()
		{
			$('#upd').click(function(e)
			{
				e.preventDefault();
				$('#add').show();
				$('#upd').hide();
				var form = $('form')[0];
				var formData= new FormData(form);
				$.ajax(
				{
					type:"POST",
					url:"<?php echo base_url();?>/index.php/Welcome/update",
					data:formData,
					cache :false,
					contentType :false,
					processData:false,
					data:formData,
					success:function(data)
					{
						alert(data);
						$.ajax(
						{
							type : "POST",
							url:"<?php echo base_url(); ?>/index.php/Welcome/show",
							success:function(data)
							{
								$('#view').html(data);
							}
						});
					}
				});
				return false;
			});
		});
	</script>
</head>
</head>
<body>
	<form  enctype="multipart/form-data">
		<table align="center" border="1" > 
		<input type="text" name="uid" value="<?php  echo $row->id;?>" hidden="">
			<tr>
				<td>Name</td>
				<td><input type="text" name="name" id="name" >
				<div class="error"><?php echo form_error('name');?></div></td>
			</tr>
			<tr>
				<td>Gender</td>
				<td><input type="radio" name="gender"  value="male" >male
					<input type="radio" name="gender" value="female" >female
					<div class="error"><?php echo form_error('gender');?></div></td>
			</tr>
			<tr>
				<td>Hobby</td>
				<td>
				<?php  $h=explode(",", $row->hobby);?>
					<input type="checkbox" name="hobby[]" value="fb" >fb
					<input type="checkbox" name="hobby[]" value="wb" >wb
					<input type="checkbox" name="hobby[]" value="bb" >bb
					<div class="error"><?php echo form_error('hobby');?></div></td>
			</tr>
			<tr>
				<td>Education</td>
				<td>
				<select name="education">
					<option>Be</option>
					<option>Me</option>
					<option>Mtech</option>
				</select>
				<div class="error"><?php echo form_error('education');?></div></td>
			</tr>
			<tr>
				<td>Image</td>
				<td><input type="file" name="img" >
				<img src="<?php echo base_url("sf/$row->image");?>" height="80" width="80">
				<div class="error"><?php echo form_error('img');?></div></td>
			</tr>
			<tr>
				<td>Gallery</td>
				<td><input type="file" name="gallery[]" multiple="">
				<?php 
				$temp=explode(",", $row->gallery);
				for($i=0;$i<count($temp);$i++){?>
				<img src="<?php echo base_url("mf/$temp[$i]"); ?>" height="80" width="80"><?php } ?>
				</td>
			</tr>
			<?php }?>
			<tr>
				<td><input type="submit" name="update" ></td>
				<td></td>
			</tr>

		</table>
	</form>
</body>
</html>
