<html>
<head>
	<title>CodeIgnitor</title>
	<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.2.1.min.js"></script>
	<script>
		$(document).ready(function()
		{
			$('.delete').click(function(e)
			{
				e.preventDefault();
				var id=$(this).attr('id');
				alert(id);
				$.ajax(
				{
					type:"POST",
					url:"<?php echo base_url(); ?>/index.php/Welcome/delete",
					data:{ 'id':id },
					success:function(data)
					{
						alert(data);
						$.ajax(
						{
							type : "POST",
							url:"<?php echo base_url(); ?>/index.php/Welcome/show",
							success:function(data)
							{
								$('#view').html(data);
							}
						});
					}
				});
				return false;
			});
		});

		$(function()
		{$('.update').click(function()
			{
				$('#submit').hide();
				$('#update').show();
				var id=$(this).attr('id');
				alert(id);

				/*$('#fb').prop('checked', false);
				$('#wb').prop('checked', false);
				$('#bb').prop('checked', false);
*/

				$.ajax(
				{
					type:"POST",
					url:"<?php echo base_url(); ?>/index.php/Welcome/edit",
					data:{ 'id' : id},
					success : function(data)
					{
						alert(data);
						var dcdata = jQuery.parseJSON(data);
						alert(dcdata[0].id);
						$('#uid').val(dcdata[0].id);
						$('#name').val(dcdata[0].name);
						if(dcdata[0].gender=="male")
						{
							$('input:radio[name=gender]')[0].checked = true;
						}
						else
						{
							$('input:radio[name=gender]')[1].checked = true;
						}
						
						if(dcdata[0].education=="Be")
						{
							$('#education').find('option:selected').text(dcdata[0].education);
						}
						if(dcdata[0].education=="Me")
						{
							$('#education').find('option:selected').text(dcdata[0].education);
						}
						if(dcdata[0].education=="Mtech")
						{
							$('#education').find('option:selected').text(dcdata[0].education);
						}
				
						var arr = new Array();
						var arr = dcdata[0].hobby.split(",");
							
						if($.inArray( "fb", arr ) !== -1)
						{ 
							$('#fb').prop('checked', true);
						}
						if($.inArray( "wb", arr ) !== -1)
						{				
							$('#wb').prop('checked', true);
						}
						if($.inArray( "bb", arr ) !== -1)
						{				
							$('#bb').prop('checked',true);
						}

						$('#imgs').html('<img src="<?php echo base_url("sf/'+dcdata[0].img+'");?>" width="80" height="80" >');

						
						$('#gallery').empty();
						var temp=dcdata[0].gallery.split(",");
						
						for(i=0;i<temp.length;i++)
						{
							$('#gallery').append('<img src="<?php echo base_url("mf/'+temp[i]+'");?>" width="80" height="80" >');
						}

						$.ajax(
						{
							type:"POST",
							url:"<?php echo base_url(); ?>/index.php/Welcome/show",
							success:function(data)
							{
								$('#view').html(data);
							}
						});
					}
				});
				return false;
			});
		});
	</script>
</head>
<body>
	<table align="center">
		<tr>
			<td>id</td>
			<td>name</td>
			<td>gender</td>
			<td>hobby</td>
			<td>education</td>
			<td>image</td>
			<td>gallery</td>
		</tr>
		<?php  
			foreach ($data as $row) {
		?>
		<tr>
			<td><?php echo $row->id;?></td>
			<td><?php echo $row->name;?></td>
			<td><?php echo $row->gender;?></td>
			<td><?php echo $row->hobby;?></td>
			<td><?php echo $row->education;?></td>
			<td>
				<img src="<?php echo base_url("sf/$row->image") ;?>" height="80" width="80"></td>
			<td><?php 
			$temp=explode(",",$row->gallery);
			for($i=0;$i<count($temp);$i++){
				?>
				<img src="<?php echo base_url("mf/$temp[$i]") ;?>" height="80" width="80"><?php }?></td>
			<td>

				<a href="#" id="<?php echo $row->id;?>" class="delete">Delete</a>
				<a href="#" id="<?php echo $row->id;?>" class="update">Edit</a></td>

		</tr>
		<?php } ?>
	</table>
</body>
</html>