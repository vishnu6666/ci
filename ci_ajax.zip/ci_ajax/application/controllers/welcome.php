<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function index()
	{
		$this->load->view('form_view');
	}
	public function validate(){
		$this->form_validation->set_rules('name','Name','required');
		$this->form_validation->set_rules('gender','Gender','required');
		$this->form_validation->set_rules('hobby','hobby','required');
		$this->form_validation->set_rules('education','education','required');
		//$this->form_validation->set_rules('img','image','required');
		//$this->form_validation->set_rules('gallery','gallery','required');
		if($this->form_validation->run()==true){
			$this->insert();
		}
		else
		{
			$this->load->view('form_view');
		}
	}
	public function insert(){
		$h=$this->input->post('hobby');
		$img=$_FILES['img']['name'];
		move_uploaded_file($_FILES['img']['tmp_name'], "sf/$img");
		$gallery=array();
			foreach ($_FILES['gallery']['name'] as $key => $value) {
				$pc=$_FILES['gallery']['name'][$key];
				move_uploaded_file($_FILES['gallery']['tmp_name'][$key], "mf/$pc");
				array_push($gallery,$pc);
			}
		$g=implode(",", $gallery);

		$data=array(
					'name'=>$this->input->post('name'),
					'gender'=>$this->input->post('gender'),
					'hobby'=>implode(",", $h),
					'education'=>$this->input->post('education'),
					'image'=>$img,
					'gallery'=>$g );
		$this->load->model('Home_model');
		if($this->Home_model->insert_data($data)){
			$data['data']=$this->Home_model->show_data();
			$this->load->view('select_view',$data);
		}
	}
	public function show(){
		$this->load->model('Home_model');
		$data['data']=$this->Home_model->show_data();
		$this->load->view('select_view',$data);
	}
	public function delete(){
		$id=$this->input->post('id',true);
		$this->load->model('Home_model');
		if($this->Home_model->delete_data($id)){
			$data['data']=$this->Home_model->show_data();
			$this->load->view('select_view',$data);
		}
	}
	public function edit(){
		$id=$this->input->post('id',true);
		$this->load->model('Home_model');
		$data=$this->Home_model->edit_data($id);
		return $data;
		}
	public function update(){
		$id=$this->input->post('uid');
		$h=$this->input->post('hobby');
		$img=$_FILES['img']['name'];
		move_uploaded_file($_FILES['img']['tmp_name'], "sf/$img");
		$gallery=array();
			foreach ($_FILES['gallery']['name'] as $key => $value) {
				$pc=$_FILES['gallery']['name'][$key];
				move_uploaded_file($_FILES['gallery']['tmp_name'][$key], "mf/$pc");
				array_push($gallery,$pc);
			}
		$g=implode(",", $gallery);

		$data=array(
					'name'=>$this->input->post('name'),
					'gender'=>$this->input->post('gender'),
					'hobby'=>implode(",", $h),
					'education'=>$this->input->post('education'),
					'image'=>$img,
					'gallery'=>$g );
		$this->load->model('Home_model');
		$this->Home_model->update_data($id,$data);
		}

	}

