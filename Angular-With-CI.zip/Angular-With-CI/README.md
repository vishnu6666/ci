# FLYERBD TUTORIAL

Angular (v-1.x) and Codeigniter (v-3.x) [Youtube Tutorial](https://www.youtube.com/watch?v=mHc-q0WjTQQ&list=PLmnDE5FTOQtkpGVC6mRs8bkzWYHTWmX2c)


## Getting Started

`bower install`

## Angular 1.x Codeigniter 3.x Project Setup | Part 2

Change git branch accordingly to tutorial.

`git checkout project-setup-part-2`

[Video Link: Angular 1.x Codeigniter 3.x Project Setup | Part 2](https://www.youtube.com/watch?v=dVBfE8kWOW8)