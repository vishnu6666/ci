<h1>This is test for........</h1>
<?php echo "<pre>";print_r($aboutus);?>
<h1> {{title}} </h1>