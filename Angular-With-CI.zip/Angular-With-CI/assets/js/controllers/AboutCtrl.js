FLYERBD
.controller('AboutCtrl', ['$scope', function ($scope) {
	$scope.title = 'This is about view';
}]);