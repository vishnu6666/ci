<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index() {
        $this->template->title = 'Welcome To Test !';
        $this->template->content->view('home/home');
        $this->template->publish();
    }

    public function aboutus() {
        $this->template->title = 'Welcome To about us page !';
        $this->template->content->view('aboutus/aboutus');
        $this->template->publish();
    }
}
