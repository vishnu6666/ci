<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
    class home_model extends CI_Model
    {

        protected $table = 'student';

                function __construct()
                {
                    parent::__construct();

                }
///////////////////////////////////////////////////////////////////////////////////////////
        function add($user)
        {
            /*echo "<pre>";
            print_r($user);
            exit();*/
            $ss = $this->db->insert('student',$user);
            if($ss)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
////////////////////////////////////////////////////////////////////////////////////////////
        function show()
        {
            $data=$this->db->get('student');
            return $data->result();
        }
////////////////////////////////////////////////////////////////////////////////////////////
        function deletedata($id)
                {
                    $this->db->where('id',$id);
                    if($this->db->delete('student'))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
////////////////////////////////////////////////////////////////////////////////////////////
        function getdata($id)
        {
            $this->db->select('*');
            $this->db->from('student');
            $this->db->where('id',$id);
            $data = $this->db->get();
            return $result = $data->result();
        }
////////////////////////////////////////////////////////////////////////////////////////////
        function updatedata($id,$user)
        {
            $this->db->where('id',$id);
            if($this->db->update('student',$user))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }