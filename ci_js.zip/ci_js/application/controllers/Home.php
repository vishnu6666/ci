<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    public function index()
    {
        $this->load->view('form_view');
                
    }
 //////////////////////////////////////////////////////////////////////////////////////////////////
    public function validate(){
    	$this->form_validation->set_rules('fname','First name','required|alpha');
		$this->form_validation->set_rules('lname','Last name','required|alpha');
		$this->form_validation->set_rules('gender','Gender','required');
		//$this->form_validation->set_rules('education','Education','required');
		$this->form_validation->set_rules('hobby[]','Hobby','required');
		if($this->form_validation->run()==true){
			$this->insert();
		}
			else
			{
				$this->load->view('form_view');
			}
		}
    
///////////////////////////////////////////////////////////////////////////////////////////////////
   public function insert()
	{
		$this->load->model('home_model');
		$h=$this->input->post('hobby');
		$pro=$_FILES['profile']['name'];
		$tmp=$_FILES['profile']['tmp_name'];
		move_uploaded_file($tmp,"upload/$pro");

		$garr=Array();
		foreach ($_FILES['gallery']['name'] as $key => $value) 
		{
			$g=$_FILES['gallery']['name'][$key];
			$gtmp=$_FILES['gallery']['tmp_name'][$key];
			move_uploaded_file($gtmp,"upload/$g");
			array_push($garr, $g);
		}
		$gname=implode(",", $garr);


		$user=array(
			'fname' =>$this->input->post('fname'),
			'lname' =>$this->input->post('lname'),
			'gender' =>$this->input->post('gender'),
			'education' =>$this->input->post('education'),
			'hobby' =>implode(",",$h),
			'profile' => $pro,
			'gallery'=>$gname
			);
		
		if($this->home_model->add($user))
		{
			$data['data']=$this->home_model->show();
			$this->load->view('display',$data);
		}
		else
		{
			echo "Error..!";
		}

	}
/////////////////////////////////////////////////////////////////////////////////////////////////////////
	public function show()
	{
		$this->load->model('home_model');
		$data['data'] = $this->home_model->show();
		$this->load->view('display',$data);
	}
///////////////////////////////////////////////////////////////////////////////////////////////////////
	public function delete($id)
		{
			$this->load->model('home_model');
			if($this->home_model->deletedata($id))
			{
				$data['data']=$this->home_model->show();
				$this->load->view('display',$data);
			}
			else
			{
				echo "Error..!";
			}
		}
////////////////////////////////////////////////////////////////////////////////////////////////////////
	public function getdata($id)
		{
			$this->load->model('home_model');
			$data['data']=$this->home_model->getdata($id);
			$this->load->view('update.php',$data);
		}
////////////////////////////////////////////////////////////////////////////////////////////////////////
	public function updatedata()
		{
			$id=$this->input->post('uid');
			$h=$this->input->post('hobby');
			$pro=$_FILES['profile']['name'];
			$tmp=$_FILES['profile']['tmp_name'];
			move_uploaded_file($tmp,"upload/$pro");

			$garr=Array();
			foreach ($_FILES['gallery']['name'] as $key => $value) 
			{
				$g=$_FILES['gallery']['name'][$key];
				$gtmp=$_FILES['gallery']['tmp_name'][$key];
				move_uploaded_file($gtmp,"upload/$g");
				array_push($garr, $g);
			}
			$gname=implode(",", $garr);
			
			$user=array(
				'fname' =>$this->input->post('fname'),
				'lname' =>$this->input->post('lname'),
				'gender' =>$this->input->post('gender'),
				'education' =>$this->input->post('education'),
				'hobby' =>implode(",",$h),
				'profile' => $pro,
				'gallery'=>$gname
				);

			$this->load->model('home_model');
			if($this->home_model->updatedata($id,$user))
			{
				$data['data']=$this->home_model->show();
				$this->load->view('display.php',$data);

			}
		}

}