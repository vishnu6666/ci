
<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
	.error{color:red };</style>

	<script type="text/javascript">
		function validate()
		{
			var fnm=document.forms['myform']['fname'].value;
			if(fnm == "")
			{
				alert("Oops..!! you forgot to insert first name..!");
				return false;
			}
			if(!/^[a-zA-Z]*$/g.test(fnm))
			{
				alert("Only characters are allow in first name..!");
				return false;
			}

			var lnm=document.forms['myform']['lname'].value;
			if(lnm=="")
			{
				alert("Oops..!! you forgot to insert last name..!");
				return false;
			}
			if(!/^[a-zA-Z]*$/g.test(lnm))
			{
				alert("Only characters are allow in last name..!");
				return false;
			}

			var gen=document.forms['myform']['gender'].value;
			if(gen=="")
			{
				alert("Oops..!! You forgot to select gender..!");
				return false;
			}

			var edu=document.forms['myform']['education'].value;
			if(edu=="null")
			{
				alert("Oops..!! You forgot to Select Education..!");
				return false;
			}

			var cri = document.getElementById('cricket').checked;
			var mu = document.getElementById('music').checked;
			var da = document.getElementById('dance').checked;
			 
			if(cri==false && mu == false && da==false)
			{
				 alert("Oops..!! You forgot to Select Hobby..!");
				 return false;
			}

			var pro=document.forms['myform']['profile'].value;
			if(pro =="")
			{
				alert("Oops..!! You forgot to Select Profile..!");
				return false;
			}
			else
			{
				
				var re = /(\.png)$/i;
				if(!re.exec(pro))
				{
						alert("Only PNG Extension Supported");
						return false;
				} 
			}

			var gal=document.forms['myform']['gallery[]'].value;
			if(gal=="")
			{
				alert("Oops..!! You forgot to Select Gallery..!");
				return false;
			}
			
			
		}
	</script>
</head>
<body>
<br><br>
	<form method="POST" name="myform" enctype="multipart/form-data" action="<?php echo base_url(); ?>index.php/Home/validate" onsubmit="return myform()">
		<div align="center" >
			<h1>-----  CodeIgnitor  -----</h1>
		</div>
		<table border="2" align="center">
			<tr>
				<th colspan="2" align="center">Insert Form</th>
			</tr>
			<tr>
				<th>First name :</th>
				<td>
					<input type="text" id="fname" name="fname">
					<div class="error"><?php echo form_error('fname'); ?></div>
				</td>
			</tr>
			<tr>
				<th>Last name :</th>
				<td>
					<input type="text" id="lname" name="lname">
					<div class="error"><?php echo form_error('lname'); ?></div>
				</td>
			</tr>
			<tr>
				<th>Gender : </th>
				<td>
					<input type="radio" id="gender" name="gender" value="Male">Male
					<input type="radio" id="gender" name="gender" value="Female">Female
					<div class="error"><?php echo form_error('gender'); ?></div>
				</td>
			</tr>
 			<tr>
				<th>Education : </th>
				<td>
					<select name="education" id="education">
						<option value="">---Select Education---</option>
						<option value="BCA">BCA</option>
						<option value="MCA">MCA</option>
						<option value="BBA">BBA</option>
					</select>
					<div class="error"><?php echo form_error('education'); ?></div>
				</td>
			</tr>
			<tr>
				<th>Hobby : </th>
				<td>
					<input type="checkbox" id="cricket" name="hobby[]" value="cricket">Cricket
					<input type="checkbox" id="music" name="hobby[]" value="music">Music
					<input type="checkbox" id="dance" name="hobby[]" value="dance">Dance
					<div class="error"><?php echo form_error('hobby[]'); ?></div>
				</td>
			</tr>
			<tr>
				<th>Profile : </th>
				<td>
					<input type="file" id="profile" name="profile">
					<div class="error"><?php echo form_error('profile'); ?></div>
				</td>
			</tr>
			<tr>
				<th>Gallery : </th>
				<td>
					<input type="file" id="gallery" name="gallery[]" multiple="">
				</td>
			</tr>
			<tr>
				<td align="center" colspan="2">	
					<input type="submit" name="submit" id="submit" value="Insert">
				</td>
			</tr>			
		</table>

	</form>

</body>
</html>