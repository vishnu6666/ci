<!DOCTYPE html>
<html>
<head>
	<title>DataTables</title>
</head>
<body>
<br><br>
	<form method="POST" action="<?php echo base_url(); ?>/index/Home/show">

		<table id="myTable" class="display nowrap" cellspacing="0" width="100%">
			<thead>
			<th>ID</th>
				<th>First name</th>
				<th>Last name</th>
				<th>Gender</th>
				<th>Education</th>
				<th>Hobby</th>
				<th>Profile</th>
				<th>Gallery</th>
				<th>PDF</th>
				<th>Action</th>
			</thead>
			<tbody>
				
			
			<?php
				foreach($data as $raw)
				{?>
					<tr>
						<td><?php echo $raw->id; ?></td>
						<td><?php echo $raw->fname; ?></td>
						<td><?php echo $raw->lname; ?></td>
						<td><?php echo $raw->gender; ?></td>
						<td><?php echo $raw->education; ?></td>
						<td><?php echo $raw->hobby; ?></td>
						<td align="center">
							<img src="<?php echo base_url("upload/$raw->profile"); ?>" width="50" height="50">
						</td>
						<td>

						<?php $gal=explode(",",$raw->gallery);
							for ($i=0; $i <count($gal); $i++) 
							{ ?>
								<img src="<?php echo base_url("upload/$gal[$i]"); ?>" height="50" width="50">	 	
						<?php } 
							?>

						</td>
						<td>
							<a href="<?php echo base_url(); ?>/index.php/Welcome/save_pdf/<?php echo $raw->id; ?>">PDF</a>
						</td>
						<td>
							<a href="<?php echo base_url(); ?>/index.php/Home/getdata/<?php echo $raw->id; ?>">Edit</a>  ||  <a href="<?php echo base_url(); ?>/index.php/Home/delete/<?php echo $raw->id; ?>">Delete</a> 
						</td>	
					</tr>
			<?php }
			?>
			</tbody>
		</table>
		
	</form>
	
</body>
</html>