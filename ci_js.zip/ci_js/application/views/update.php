<!DOCTYPE html>
<html>
<head>
	<script type="text/javascript">
		function validate()
		{
			var fnm=document.forms['myform']['fname'].value;
			if(fnm == "")
			{
				alert("Oops..!! you forgot to insert first name..!");
				return false;
			}
			if(!/^[a-zA-Z]*$/g.test(fnm))
			{
				alert("Only characters are allow in first name..!");
				return false;
			}

			var lnm=document.forms['myform']['lname'].value;
			if(lnm=="")
			{
				alert("Oops..!! you forgot to insert last name..!");
				return false;
			}
			if(!/^[a-zA-Z]*$/g.test(lnm))
			{
				alert("Only characters are allow in last name..!");
				return false;
			}

			var gen=document.forms['myform']['gender'].value;
			if(gen=="")
			{
				alert("Oops..!! You forgot to select gender..!");
				return false;
			}

			var edu=document.forms['myform']['education'].value;
			if(edu=="null")
			{
				alert("Oops..!! You forgot to Select Education..!");
				return false;
			}

			var cri = document.getElementById('cricket').checked;
			var mu = document.getElementById('music').checked;
			var da = document.getElementById('dance').checked;
			 
			if(cri==false && mu == false && da==false)
			{
				 alert("Oops..!! You forgot to Select Hobby..!");
				 return false;
			}

			var pro=document.forms['myform']['profile'].value;
			if(pro =="")
			{
				alert("Oops..!! You forgot to Select Profile..!");
				return false;
			}
			else
			{
				
				var re = /(\.png)$/i;
				if(!re.exec(pro))
				{
						alert("Only PNG Extension Supported");
						return false;
				} 
			}

			var gal=document.forms['myform']['gallery[]'].value;
			if(gal=="")
			{
				alert("Oops..!! You forgot to Select Gallery..!");
				return false;
			}
			
			
		}
	</script>
</head>
<body>
<?php
	foreach ($data as $raw) {
		
	} 
?>
	<form method="POST" name="myform" onsubmit="return validate()" enctype="multipart/form-data" action="<?php echo base_url(); ?>/index.php/Home/updatedata">
	<div align="center"><h1>--- Update Form --- </h1></div>
		<table border="2" align="center">
			<input type="text" name="uid" value="<?php echo $raw->id; ?>" hidden="">
			<tr>
				<th>First name :</th>
				<td>
					<input type="text" name="fname" value="<?php echo $raw->fname; ?>">
				</td>
			</tr>
			<tr>
				<th>Last name :</th>
				<td>
					<input type="text" name="lname" value="<?php echo $raw->lname; ?>">
				</td>
			</tr>
			<tr>
				<th>Gender : </th>
				<td>
					<input type="radio" name="gender" <?php if($raw->gender=="Male"){echo 'checked';} ?> value="Male">Male
					<input type="radio" name="gender" <?php if($raw->gender=="Female"){echo 'checked';} ?> value="Female">Female
				</td>
			</tr>
			<tr>
				<th>Education</th>
				<td>
					<select name="education">
						<option value="null" <?php if($raw->education=="null"){?> selected=selected<?php } ?> >- Select Education -</option>
						<option value="BCA" <?php if($raw->education=="BCA"){?> selected=selected<?php } ?> >BCA</option>
						<option value="MCA" <?php if($raw->education=="MCA"){?> selected=selected<?php } ?> >MCA</option>
						<option value="BBA" <?php if($raw->education=="BBA"){?> selected=selected<?php } ?> >BBA</option>
					</select>
				</td>	
			</tr>
			<tr>
				<th>Hobby : </th>
				<td>
				<?php $h=explode(",",$raw->hobby);
				 ?>
					<input type="checkbox" name="hobby[]" <?php if(in_array("cricket",$h)){echo "checked";} ?> value="cricket">Cricket
					<input type="checkbox" name="hobby[]" <?php if(in_array("music",$h)){echo "checked";} ?> value="music">Music
					<input type="checkbox" name="hobby[]" <?php if(in_array("dance",$h)){echo "checked";} ?> value="dance">Dance
				</td>
			</tr>
			<tr>
				<th>Profile : </th>
				<td>
					<input type="file" name="profile">
					<img src="<?php echo base_url("upload/$raw->profile"); ?>" height="50" width="50">
				</td>
			</tr>
			<tr>
				<th>Gallery : </th>
				<td>
					<input type="file" name="gallery[]" multiple="">
					<?php $gal=explode(",",$raw->gallery);
							for ($i=0; $i <count($gal); $i++) 
							{ ?>
								<img src="<?php echo base_url("upload/$gal[$i]"); ?>" height="50" width="50">	 	
						<?php } 
							?>
				</td>
			</tr>
			<tr>
				<td colspan="2" align="center">
					<input type="submit" name="submit" value="Update">
				</td>
			</tr>
		</table>
	</form>
</body>
</html>