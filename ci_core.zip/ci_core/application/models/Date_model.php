<?php
class Date_model extends CI_Model {
	 public function show_data()
        {
                $query = $this->db->get('date_show', 10);
                return $query->result();
        }
        public function show_range_data($from,$to){
        	$this->db->select('*');
        	//$this->db->from('date_show');
        	
        	$this->db->where('s_date BETWEEN "'. date('Y-m-d', strtotime($from)). '" and "'. date('Y-m-d', strtotime($to)).'"');
        	$this->db->where('e_date BETWEEN "'. date('Y-m-d', strtotime($from)). '" and "'. date('Y-m-d', strtotime($to)).'"');
			
			$sql=$this->db->get('date_show');
			return $sql->result();
        	/*echo "<pre>";
        	print_r($sql);
        	exit();*/
        }
}

 ?>