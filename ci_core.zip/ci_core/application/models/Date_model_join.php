<?php
class Date_model_join extends CI_Model {

                public function show_data()
                {
                $this->db->select('payment.*,date_show.*');
                $this->db->from('date_show');
                $this->db->join('payment', 'date_show.id = payment.data_show_id','inner');
                $query = $this->db->get();
               /* echo"<pre>";
                print_r($query);
                exit();*/
                return $query->result();
 
        }
        public function show_range_data($from,$to){
                $this->db->select('payment.*,date_show.*');
                $this->db->from('payment');
                $this->db->join('date_show', 'date_show.id = payment.data_show_id','inner');
                $this->db->or_where('date_show.s_date BETWEEN "'. date('Y-m-d', strtotime($from)). '" and "'. date('Y-m-d', strtotime($to)).'"' , 'payment.end_date BETWEEN "'. date('Y-m-d', strtotime($from)). '" and "'. date('Y-m-d', strtotime($to)).'"');
                $query = $this->db->get();
               /* echo"<pre>";
                print_r($query);
                exit();*/
                return $query->result();
 
        }
        public function show_range_data_in_pdf($from,$to){
                $this->db->select('payment.*,date_show.*');
                $this->db->from('payment');
                $this->db->join('date_show', 'date_show.id = payment.data_show_id','inner');
                $this->db->or_where('date_show.s_date BETWEEN "'. date('Y-m-d', strtotime($from)). '" and "'. date('Y-m-d', strtotime($to)).'"' , 'payment.end_date BETWEEN "'. date('Y-m-d', strtotime($from)). '" and "'. date('Y-m-d', strtotime($to)).'"');
                $query = $this->db->get();
               /* echo"<pre>";
                print_r($query);
                exit();*/
                return $query->result();
 
        }
}

 ?>