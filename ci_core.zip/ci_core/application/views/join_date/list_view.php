<html>
	<body>

		<table>
			<tr>
				<td>id</td>
				<td>s_date</td>
				<td>from</td>
				<td>name</td>
				<td>end_date</td>
				<td>email</td>
			</tr>
			<?php  foreach ($data as $row) { ?> 
			<tr>
				<td><?php  echo $row->id;?></td>
				<td><?php  echo $row->s_date;?></td>
				<td><?php  echo $row->from;?></td>
				<td><?php  echo $row->name;?></td>
				<td><?php  echo $row->end_date;?></td>
				<td><?php  echo $row->email;?></td>
			</tr>
			<?php }?>
		</table>

	</body>
</html>
