<html>
<head>
	<style type="text/css">
	.error{color:red};</style>
</head>
<body>
<?php 
		foreach ($data as $row) {
		?>
	<form action="<?php echo base_url();?>index.php/Welcome/update" method="POST" enctype="multipart/form-data">
		<table align="center" border="1" > 
		<input type="hidden" name="uid" value="<?php  echo $row->id;?>" hidden="">
			<tr>
				<td>Name</td>
				<td><input type="text" name="name" id="name" value="<?php echo $row->name?>">
				<div class="error"><?php echo form_error('name');?></div></td>
			</tr>
			<tr>
				<td>Gender</td>
				<td><input type="radio" name="gender"  value="male" <?php if($row->gender=='male'){echo "checked";}?>>male
					<input type="radio" name="gender" value="female"  <?php if($row->gender=='female'){echo "checked";}?>>female
					<div class="error"><?php echo form_error('gender');?></div></td>
			</tr>
			<tr>
				<td>Hobby</td>
				<td>
				<?php  $h=explode(",", $row->hobby);?>
					<input type="checkbox" name="hobby[]" value="fb"  <?php if(in_array('fb',$h)){echo"checked";}?>>fb
					<input type="checkbox" name="hobby[]" value="wb" <?php if(in_array('wb',$h)){echo "checked";}?>>wb
					<input type="checkbox" name="hobby[]" value="bb" <?php if(in_array('bb',$h)){echo "checked";}?>>bb
					<div class="error"><?php echo form_error('hobby');?></div></td>
			</tr>
			<tr>
				<td>Education</td>
				<td>
				<select name="education">
					<option <?php if($row->education=='Be'){echo "selected";}?>>Be</option>
					<option <?php if($row->education=='Me'){echo "selected";}?>>Me</option>
					<option <?php if($row->education=='Mtech'){echo "selected";}?>>Mtech</option>
				</select>
				<div class="error"><?php echo form_error('education');?></div></td>
			</tr>
			<tr>
				<td>Image</td>
				<td><input type="file" name="img" >
				<img src="<?php echo base_url("sf/$row->image");?>" height="80" width="80">
				<div class="error"><?php echo form_error('img');?></div></td>
			</tr>
			<tr>
				<td>Gallery</td>
				<td><input type="file" name="gallery[]" multiple="">
				<?php 
				$temp=explode(",", $row->gallery);
				for($i=0;$i<count($temp);$i++){?>
				<img src="<?php echo base_url("mf/$temp[$i]"); ?>" height="80" width="80"><?php } ?>
				</td>
			</tr>
			<?php }?>
			<tr>
				<td><input type="submit" name="update" ></td>
				<td></td>
			</tr>

		</table>
	</form>
</body>
</html>
