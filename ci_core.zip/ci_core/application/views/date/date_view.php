<html>
	<body>
		<form action="<?php echo base_url();?>/index.php/Date_reaport/show_range_user" method="POST">
			<table>
				<tr>
					<td>Select Start Date:</td>
					<td><input type="date" name="s_date"></td>
				</tr>
				<tr>
					<td>End Date</td>
					<td><input type="date" name="e_date"></td>
				</tr>
				<tr>
					<td><input type="submit" name="submit" value="submit"></td>
					<td></td>
				</tr>
			</table>
		</form>
	</body>
</html>