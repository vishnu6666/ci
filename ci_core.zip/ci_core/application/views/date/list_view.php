<html>
	<body>
		<table>
			<tr>
				<td>id</td>
				<td>s_date</td>
				<td>from</td>
				<td>name</td>
				<td>e_date</td>
			</tr>
			<?php  foreach ($data as $row) { ?> 
			<tr>
				<td><?php  echo $row->id;?></td>
				<td><?php  echo $row->s_date;?></td>
				<td><?php  echo $row->from;?></td>
				<td><?php  echo $row->name;?></td>
				<td><?php  echo $row->e_date;?></td>
			</tr>
			<?php }?>
		</table>
	</body>
</html>
