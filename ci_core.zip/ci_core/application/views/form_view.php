<html>
<head>
	<style type="text/css">
	.error{color:red};</style>
</head>
<body>
	<form action="<?php echo base_url();?>index.php/Welcome/validate" method="POST" enctype="multipart/form-data">
		<table align="center" border="1" > 
			<tr>
				<td>Name</td>
				<td><input type="text" name="name" id="name"value="">
				<div class="error"><?php echo form_error('name');?></div></td>
			</tr>
			<tr>
				<td>Gender</td>
				<td><input type="radio" name="gender"  value="male">male
					<input type="radio" name="gender" value="female">female
					<div class="error"><?php echo form_error('gender');?></div></td>
			</tr>
			<tr>
				<td>Hobby</td>
				<td><input type="checkbox" name="hobby[]" value="fb">fb
					<input type="checkbox" name="hobby[]" value="wb">wb
					<input type="checkbox" name="hobby[]" value="bb">bb
					<div class="error"><?php echo form_error('hobby');?></div></td>
			</tr>
			<tr>
				<td>Education</td>
				<td>
				<select name="education">
					<option>Be</option>
					<option>Me</option>
					<option>Mtech</option>
				</select>
				<div class="error"><?php echo form_error('education');?></div></td>
			</tr>
			<tr>
				<td>Image</td>
				<td><input type="file" name="img" >
				<div class="error"><?php echo form_error('img');?></div></td>
			</tr>
			<tr>
				<td>Gallery</td>
				<td><input type="file" name="gallery[]" multiple="">
				</td>
			</tr>
			<tr>
				<td><input type="submit" name="submit" ></td>
				<td></td>
			</tr>

		</table>
	</form>
</body>
</html>
