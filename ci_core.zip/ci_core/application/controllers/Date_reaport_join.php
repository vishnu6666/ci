
<?php
class Date_reaport_join extends CI_Controller {

	  public function __construct()
        {
                parent::__construct();
                $this->load->model('Date_model_join');  
        }
        public function index()
        {
           $this->load->view('join_date/date_view'); 
           $data['data']=$this->Date_model_join->show_data(); 
           $this->load->view('join_date/list_view',$data);
        }
        public function show_range_user(){
        		$from =$this->input->post('s_date');
        		$to =$this->input->post('e_date');
        /*	echo "<pre>";
        	print_r($from);
        	exit();*/
        	 if($data['data']=$this->Date_model_join->show_range_data($from,$to)){
        	 	$this->load->view('join_date/date_view'); 
        	 	$this->load->view('join_date/list_view_pdf',$data);
        	 	$this->report_pdf($data);
        	 }
        }
        public function report_pdf(){
        ini_set('memory_limit', '256M');
        // load library
        $this->load->library('pdf');
        $pdf = $this->pdf->load();
        // retrieve data from model
       // $data['data'] = $this->Date_model_join->show_range_data_in_pdf();
        $data['title'] = "items";

        // boost the memory limit if it's low ;)
        $html = $this->load->view('join_date/list_view_pdf', $data, true);
        // render the view into HTML
        $pdf->WriteHTML($html);
        // write the HTML into the PDF
        $output = 'itemreport' . date('Y_m_d_H_i_s') . '_.pdf';
        $pdf->Output("", 'I');
        // save to file because we can exit();
        // - See more at: http://webeasystep.com/blog/view_article/codeigniter_tutorial_pdf_to_create_your_reports#sthash.QFCyVGLu.dpuf
    
        }
}