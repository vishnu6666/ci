<?php
class Date_reaport extends CI_Controller {

	  public function __construct()
        {
                parent::__construct();
                $this->load->model('Date_model');  
        }
        public function index()
        {
           $this->load->view('date/date_view'); 
           $data['data']=$this->Date_model->show_data(); 
           $this->load->view('date/list_view',$data);
        }
        public function show_range_user(){
        		$from =$this->input->post('s_date');
        		$to =$this->input->post('e_date');
        /*	echo "<pre>";
        	print_r($from);
        	exit();*/
        	 $data['data']=$this->Date_model->show_range_data($from,$to); 
        	  $this->load->view('date/date_view'); 
        	 $this->load->view('date/list_view',$data);
        }
}